public class DebugCommandResult {
}
